<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Task;

class TaskController extends Controller
{   public function index()
    // {   $id = '';
    //     $tasks = Task::getData($id);
    // foreach($tasks as $task){
    //     $task->format();
    // }
    //     return view('todolist.list');
    {
        // $items = DB::select('select * from tasks');
        // return view('todolist.list',['items'=>$items]);
        $tasks = Task::orderBy('id','asc')->get();
        return view('todolist.list',["tasks"=>$tasks]);
    }

    public function createTask()
    {
        return view('todolist.task_create');
    }

    public function create(Request $request)
    {
            $task = new Task();
            $task->status = $request -> status ;
            $task->title = $request -> title ;
            $task->due_date = $request -> due_date ;
            $task->assignee = $request -> assignee ;
            $task->save();
        return redirect('/');
    }
}
