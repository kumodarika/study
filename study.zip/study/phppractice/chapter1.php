<?php
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Todoリスト</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>Todoリスト</h1>
    <hr>
    <div class="boardWrapper">
        <p>{{$msg}}</p>
        <form class="formWrapper">
            <div>
                <label for="">タスク：</label>
                <input type="text" name="taskName">
                <input type="submit" value="入力">
            </div>

    <!-- <p>{{$msg}}</p>
    <form method="POST" action="/list">
        @csrf
        <input type="text" name="msg">
        <input type="submit">
    </form> -->
</body>
</html>