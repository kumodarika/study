<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\TaskController;

// Route::get('/', function () {
//     return view('welcome');
// });

// Route::prefix('todolist')
// ->middleware(['auth'])
// ->controller(TaskController::class)
// ->name('todolist.')
// ->group(function(){
//     Route::get('/list')->name('list');
//     Route::get('/addList')->name('addList');
// });

// Route::get('/list', function () {
//     return view('todolist.list');
// });
// Route::get('/list/addList', function () {
//     return view('todolist.addList');
// });
Route::get('/','App\Http\Controllers\TaskController@index')->name('home');
Route::get('/create-task','App\Http\Controllers\TaskController@createTask');
Route::post('/create','App\Http\Controllers\TaskController@create');
// Route::get('todolist/list','App\Http\Controllers\TaskController@index')->name('todolist.list');
// Route::get('todolist/addlist','App\Http\Controllers\TaskController@addList')->name('todolist.addList');
// Route::post('/add','App\Http\Controllers\TaskController@insert');