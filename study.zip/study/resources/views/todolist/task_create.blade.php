<!DOCTYPE html>
<html lang="ja">

<head>
    <meta charset="UTF-8">
    <title>タスク追加ページ</title>
    <!-- <link href=".css" rel="stylesheet"> -->
</head>

<body>
    <div>
        <h2>タスクの追加</h2>
        <!-- <form method="POST" action="{{url('/create')}}"> -->
        <form method="POST" action="{{ url('/create') }}">
            ・状態：<select name="status">
                <option value="">選択してください</option>
                <option value="1">未了</option>
                <option value="2">処理中</option>
                <option value="3">完了</option>
            </select>
            </br>
            ・タイトル：<input type="textarea" name="title"><br>
            ・期日：<input type="date" name="due_date"><br>
            ・担当：<input type="text" name="assignee"><br>
            <input type="submit" name="create" value="追加">
        </form>
        <a class="back" href="{{ route('home') }}">戻る</a>
    </div>
</body>