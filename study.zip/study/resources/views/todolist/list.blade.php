
<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <title>タスク管理アプリ</title>
    <!-- <link href=".css" rel="stylesheet"> -->
</head>
<body>
    <div class="container mt-5">
        <h1>タスク一覧</h1>
        <!-- <input type="button" onclick="location.href='http://localhost/study/public/todolist/addlist'" value="追加"> -->
        <a href="{{url('/create-task')}}" class="btn">追加</a>
        <table border="1">
        <!-- class="table table-striped table-bordered mt-4" -->
            <tr>
                <th>ID</th>
                <th>状態</th>
                <th>タイトル</th>
                <th>期日</th>
                <th>担当</th>
                <th colspan="2">アクション</th>
            </tr>
            @foreach($tasks as $task)
            <tr>
                <td>{{$task->id}}</td>
                <td>{{$task->status}}</td>
                <td>{{$task->title}}</td>
                <td>{{$task->due_date}}</td>
                <td>{{$task->assignee}}</td>
                <td><a href="/edit/{{$task->id}}">編集</a></td>
                <td><a href="/delete/{{$task->id}}">削除</a></td>
            </tr>
            @endforeach
        </table>
    </div>
</body>

</html>