
<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <title>タスク管理アプリ</title>
    <!-- <link href=".css" rel="stylesheet"> -->
</head>
<body>
    <div class="container mt-5">
        <h1>タスク一覧</h1>
        <!-- <input type="button" onclick="location.href='http://localhost/study/public/todolist/addlist'" value="追加"> -->
        <a href="<?php echo e(url('/create-task')); ?>" class="btn">追加</a>
        <table border="1">
        <!-- class="table table-striped table-bordered mt-4" -->
            <tr>
                <th>ID</th>
                <th>状態</th>
                <th>タイトル</th>
                <th>期日</th>
                <th>担当</th>
                <th colspan="2">アクション</th>
            </tr>
            <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($task->id); ?></td>
                <td><?php echo e($task->status); ?></td>
                <td><?php echo e($task->title); ?></td>
                <td><?php echo e($task->due_date); ?></td>
                <td><?php echo e($task->assignee); ?></td>
                <td><a href="/edit/<?php echo e($task->id); ?>">編集</a></td>
                <td><a href="/delete/<?php echo e($task->id); ?>">削除</a></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>
</body>

</html><?php /**PATH C:\xampp\htdocs\study\resources\views/todolist/list.blade.php ENDPATH**/ ?>